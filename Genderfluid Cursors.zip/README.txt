Hello! Thank you for downloading these genderfluid cursors that I made! It was a lot of fun making them.

Here's how to install them:
First, extract all of these files to the "C:/Windows/Cursors" folder on your computer. This will ensure that the cursors persist even after a reboot.

Next, you'll need to open the "Mouse Properties" window, in which there are 2 easy ways to do it:

First, you can access it through the Windows Search feature by typing "main.cpl" and hitting enter. This will bring up the "Mouse Properties" window.
Alternatively, you can use the "Run" box by pressing "Windows key + R" and then typing "main.cpl" and hitting enter. This will also bring up the "Mouse Properties" window.
Or you can just use the shortcut to Mouse Properties at the bottom of the folder.

In the "Mouse Properties" window, click on the "Pointers" tab.

To change the cursor for each specific action, click on the action in the list, then click the "Browse" button to locate and select the corresponding cursor file from the "C:/Windows/Cursors" folder.

Once you've selected the cursor file for each action, click "Apply" and then "OK" to save your changes.

That's it! Your new custom genderfluid cursors should now be applied and ready to use, and they will persist even after a reboot. Enjoy!
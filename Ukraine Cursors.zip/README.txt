Hello! Thank you for downloading these Ukraine styled cursors that I made! It was a lot of fun making them.

Here's how to install them:
First, extract all of these files to the "C:/Windows/Cursors" folder on your computer. This will ensure that the cursors persist even after a reboot.

Next, you'll need to open the "Mouse Properties" window, in which there are 2 easy ways to do it:

First, you can access it through the Windows Search feature by typing "main.cpl" and hitting enter. This will bring up the "Mouse Properties" window.
Alternatively, you can use the "Run" box by pressing "Windows key + R" and then typing "main.cpl" and hitting enter. This will also bring up the "Mouse Properties" window.
Or you can just use the shortcut to Mouse Properties at the bottom of the folder.

In the "Mouse Properties" window, click on the "Pointers" tab.

To change the cursor for each specific action, click on the action in the list, then click the "Browse" button to locate and select the corresponding cursor file from the "C:/Windows/Cursors" folder.

Once you've selected the cursor file for each action, click "Apply" and then "OK" to save your changes.

That's it! Your new custom Ukraine cursors should now be applied and ready to use, and they will persist even after a reboot. Enjoy!

Licensing:

The mouse cursors depicting the Ukrainian flag are created by Pokemonhacker1337 (u/PKHacker1337) and are released under an open license. You are granted the following permissions:

Usage: You are free to use the cursors for personal or commercial purposes without any restrictions.
Modification: You are allowed to modify, adapt, or customize the cursors to suit your needs or preferences.
Distribution: You may distribute the cursors to others, share them online, or include them in software applications or digital content.
Attribution: While attribution is not required, it is greatly appreciated. You may provide credit to me for creating the original mouse cursors, but it is not mandatory.

Tl;dr: Do whatever you want with them, I don't mind. If you do anything with them, I'd love it if you told me, but you don't have to. I can't be bothered to set up any actual licensing.

Supportive Message:

In light of the ongoing conflict and challenges faced by Ukraine, we stand in solidarity with the Ukrainian people. We admire the resilience, strength, and courage displayed during these difficult times. Your unwavering spirit inspires us all.

To the people of Ukraine, know that you are not alone. We offer our support and solidarity as you strive for peace, freedom, and sovereignty. We hope for a swift resolution to the conflict and the restoration of stability and harmony.

We believe in the power of unity, compassion, and understanding. Together, we can work towards a future where every nation can thrive in peace and prosperity. Stay strong, Ukraine. Our thoughts and support are with you.